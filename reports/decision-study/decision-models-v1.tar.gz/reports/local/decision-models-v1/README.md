# decision-v1：相同候选下的真实模型对照

模型只看到完整状态、规则和共同合法候选，不接收评价或最佳标签；直接执行原始选择，无纠错、无重试。合法候选枚举和路径执行仍由程序提供，因此不是完全无辅助测试。

游戏种子：[20260924, 20260925, 20260926]；展示种子：[0, 1]。每局最多 2000 动作/请求；展示重复不算新增独立游戏种子。

## 本轮判断

60 局尝试全部结束，52 局获得自然终止或预算终止的游戏结果，8 局请求失败。不能把 60/60 写成成功率。全部 47221 个实际动作通过离线回放；回放通过不代表模型策略有效。

- 方块：纯程序六局全部达到 2000 步，三个游戏种子的分数为 6200、5600、6000，两种展示排列一致。模型有效的 15 局全部堆顶；其中 Qwen 一局 100 分，其余 14 局 0 分。没有观察到模型相对程序的得分增益。随机组均为 0 分，现有样本也不足以证明模型稳定优于随机。
- JEV 蛇：只有第一个游戏种子的两个排列取得完整预算结果，分别为 80、90 分，纯程序为 850 分，随机为 30 分。它在这个种子上优于随机，明显低于程序；不能据此推成三个独立种子的均值或稳定优势。第二种子两局中断，第三种子未执行有效动作。
- Laya 蛇五个有效局依次为 90、20、40、30、50 分；对应随机分数为 30、30、50、50、60，配对分差为 +60、-10、-10、-20、-10，平均 +2 分。Qwen 六局对应随机分差为 +20、+20、-30、0、+10、-10，平均 +1.7 分。两者都没有持续优于随机的证据，且所有有效蛇局均受困结束。重复展示仅是同一种子的重复条件，不能当成五或六个独立样本。
- 展示敏感性：Laya 第一个种子的两种排列从 90 分变为 20 分；Qwen 第二个种子方块从 0 分变为 100 分。顺序和编号一起变化，尚不能区分二者的作用；JEV 还可能受云端推理非确定性影响。

本轮测的是共同合法候选和执行器下的策略价值，不等同于完全无辅助。它与旧版有标签/纠错的测试使用不同种子和协议，不能用跨轮分差计算辅助的贡献百分比。要证明模型稳定增益，需要更多独立种子；现有有效结果支持在这些游戏和规则下优先使用程序策略。

## 基础设施中断

JEV 20260925/0 蛇局在 1035 步、80 分后收到上游 HTTP 529；20260925/1 蛇局在 275 步、10 分后本地连接提前关闭。随后 8770 和 8769 不再监听，导致第三种子 JEV 四局、Laya 第二排列两局首步连接拒绝。服务退出原因未查明；没有收到停止这两个服务的用户指令。8 条记录不重试、不覆盖，也不将其低分计入策略均值。

## 每局结果

| 游戏种子 | 展示种子 | 策略 | 游戏 | 动作 | 得分 | 比程序 | 比随机 | 落块/消行 | 请求 | 终止原因 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| 20260924 | 0 | jev | snake | 2000 | 80 | -770 | +50 | — | 2000 | step_cap |
| 20260924 | 0 | jev | tetris | 109 | 0 | -6200 | +0 | 17/0 | 17 | spawn_blocked |
| 20260924 | 0 | laya | snake | 1261 | 90 | -760 | +60 | — | 1261 | no_legal_actions |
| 20260924 | 0 | laya | tetris | 194 | 0 | -6200 | +0 | 18/0 | 18 | spawn_blocked |
| 20260924 | 0 | program | snake | 2000 | 850 | +0 | +820 | — | 0 | step_cap |
| 20260924 | 0 | program | tetris | 2000 | 6200 | +0 | +6200 | 144/53 | 0 | step_cap |
| 20260924 | 0 | qwen08 | snake | 733 | 50 | -800 | +20 | — | 733 | no_legal_actions |
| 20260924 | 0 | qwen08 | tetris | 243 | 0 | -6200 | +0 | 23/0 | 23 | spawn_blocked |
| 20260924 | 0 | random | snake | 576 | 30 | -820 | +0 | — | 0 | no_legal_actions |
| 20260924 | 0 | random | tetris | 284 | 0 | -6200 | +0 | 27/0 | 0 | spawn_blocked |
| 20260924 | 1 | jev | snake | 2000 | 90 | -760 | +60 | — | 2000 | step_cap |
| 20260924 | 1 | jev | tetris | 136 | 0 | -6200 | +0 | 21/0 | 21 | spawn_blocked |
| 20260924 | 1 | laya | snake | 412 | 20 | -830 | -10 | — | 412 | no_legal_actions |
| 20260924 | 1 | laya | tetris | 242 | 0 | -6200 | +0 | 22/0 | 22 | spawn_blocked |
| 20260924 | 1 | program | snake | 2000 | 850 | +0 | +820 | — | 0 | step_cap |
| 20260924 | 1 | program | tetris | 2000 | 6200 | +0 | +6200 | 144/53 | 0 | step_cap |
| 20260924 | 1 | qwen08 | snake | 999 | 50 | -800 | +20 | — | 999 | no_legal_actions |
| 20260924 | 1 | qwen08 | tetris | 222 | 0 | -6200 | +0 | 20/0 | 20 | spawn_blocked |
| 20260924 | 1 | random | snake | 576 | 30 | -820 | +0 | — | 0 | no_legal_actions |
| 20260924 | 1 | random | tetris | 284 | 0 | -6200 | +0 | 27/0 | 0 | spawn_blocked |
| 20260925 | 0 | jev | snake | 1035 | 80 | — | — | — | 1036 | request_error |
| 20260925 | 0 | jev | tetris | 141 | 0 | -5600 | +0 | 16/0 | 16 | spawn_blocked |
| 20260925 | 0 | laya | snake | 1182 | 40 | -810 | -10 | — | 1182 | no_legal_actions |
| 20260925 | 0 | laya | tetris | 246 | 0 | -5600 | +0 | 23/0 | 23 | spawn_blocked |
| 20260925 | 0 | program | snake | 2000 | 850 | +0 | +800 | — | 0 | step_cap |
| 20260925 | 0 | program | tetris | 2000 | 5600 | +0 | +5600 | 123/48 | 0 | step_cap |
| 20260925 | 0 | qwen08 | snake | 288 | 20 | -830 | -30 | — | 288 | no_legal_actions |
| 20260925 | 0 | qwen08 | tetris | 199 | 0 | -5600 | +0 | 18/0 | 18 | spawn_blocked |
| 20260925 | 0 | random | snake | 1038 | 50 | -800 | +0 | — | 0 | no_legal_actions |
| 20260925 | 0 | random | tetris | 160 | 0 | -5600 | +0 | 15/0 | 0 | spawn_blocked |
| 20260925 | 1 | jev | snake | 275 | 10 | — | — | — | 276 | request_error |
| 20260925 | 1 | jev | tetris | 181 | 0 | -5600 | +0 | 21/0 | 21 | spawn_blocked |
| 20260925 | 1 | laya | snake | 718 | 30 | -820 | -20 | — | 718 | no_legal_actions |
| 20260925 | 1 | laya | tetris | 221 | 0 | -5600 | +0 | 20/0 | 20 | spawn_blocked |
| 20260925 | 1 | program | snake | 2000 | 850 | +0 | +800 | — | 0 | step_cap |
| 20260925 | 1 | program | tetris | 2000 | 5600 | +0 | +5600 | 123/48 | 0 | step_cap |
| 20260925 | 1 | qwen08 | snake | 988 | 50 | -800 | +0 | — | 988 | no_legal_actions |
| 20260925 | 1 | qwen08 | tetris | 160 | 100 | -5500 | +100 | 19/1 | 19 | spawn_blocked |
| 20260925 | 1 | random | snake | 1038 | 50 | -800 | +0 | — | 0 | no_legal_actions |
| 20260925 | 1 | random | tetris | 160 | 0 | -5600 | +0 | 15/0 | 0 | spawn_blocked |
| 20260926 | 0 | jev | snake | 0 | 未执行 | — | — | — | 1 | request_error |
| 20260926 | 0 | jev | tetris | 0 | 未执行 | — | — | 0/0 | 1 | request_error |
| 20260926 | 0 | laya | snake | 1054 | 50 | -730 | -10 | — | 1054 | no_legal_actions |
| 20260926 | 0 | laya | tetris | 211 | 0 | -6000 | +0 | 18/0 | 18 | spawn_blocked |
| 20260926 | 0 | program | snake | 2000 | 780 | +0 | +720 | — | 0 | step_cap |
| 20260926 | 0 | program | tetris | 2000 | 6000 | +0 | +6000 | 128/50 | 0 | step_cap |
| 20260926 | 0 | qwen08 | snake | 926 | 70 | -710 | +10 | — | 926 | no_legal_actions |
| 20260926 | 0 | qwen08 | tetris | 200 | 0 | -6000 | +0 | 18/0 | 18 | spawn_blocked |
| 20260926 | 0 | random | snake | 838 | 60 | -720 | +0 | — | 0 | no_legal_actions |
| 20260926 | 0 | random | tetris | 166 | 0 | -6000 | +0 | 17/0 | 0 | spawn_blocked |
| 20260926 | 1 | jev | snake | 0 | 未执行 | — | — | — | 1 | request_error |
| 20260926 | 1 | jev | tetris | 0 | 未执行 | — | — | 0/0 | 1 | request_error |
| 20260926 | 1 | laya | snake | 0 | 未执行 | — | — | — | 1 | request_error |
| 20260926 | 1 | laya | tetris | 0 | 未执行 | — | — | 0/0 | 1 | request_error |
| 20260926 | 1 | program | snake | 2000 | 780 | +0 | +720 | — | 0 | step_cap |
| 20260926 | 1 | program | tetris | 2000 | 6000 | +0 | +6000 | 128/50 | 0 | step_cap |
| 20260926 | 1 | qwen08 | snake | 348 | 50 | -730 | -10 | — | 348 | no_legal_actions |
| 20260926 | 1 | qwen08 | tetris | 173 | 0 | -6000 | +0 | 16/0 | 16 | spawn_blocked |
| 20260926 | 1 | random | snake | 838 | 60 | -720 | +0 | — | 0 | no_legal_actions |
| 20260926 | 1 | random | tetris | 166 | 0 | -6000 | +0 | 17/0 | 0 | spawn_blocked |

请求或协议失败不计算策略分差；得分仅为中断时进度，首步失败记为未执行。受困（no_legal_actions）表示没有合法下一步，不是存活完成。达到上限不证明无限存活。

## 展示排列敏感性

| 模型 | 游戏种子 | 游戏 | 各展示种子的得分 | 各展示种子的终止原因 |
| --- | --- | --- | --- | --- |
| jev | 20260924 | tetris | 0, 0 | spawn_blocked, spawn_blocked |
| jev | 20260924 | snake | 80, 90 | step_cap, step_cap |
| jev | 20260925 | tetris | 0, 0 | spawn_blocked, spawn_blocked |
| jev | 20260925 | snake | 中断, 中断 | request_error, request_error |
| jev | 20260926 | tetris | 中断, 中断 | request_error, request_error |
| jev | 20260926 | snake | 中断, 中断 | request_error, request_error |
| laya | 20260924 | tetris | 0, 0 | spawn_blocked, spawn_blocked |
| laya | 20260924 | snake | 90, 20 | no_legal_actions, no_legal_actions |
| laya | 20260925 | tetris | 0, 0 | spawn_blocked, spawn_blocked |
| laya | 20260925 | snake | 40, 30 | no_legal_actions, no_legal_actions |
| laya | 20260926 | tetris | 0, 中断 | spawn_blocked, request_error |
| laya | 20260926 | snake | 50, 中断 | no_legal_actions, request_error |
| qwen08 | 20260924 | tetris | 0, 0 | spawn_blocked, spawn_blocked |
| qwen08 | 20260924 | snake | 50, 50 | no_legal_actions, no_legal_actions |
| qwen08 | 20260925 | tetris | 0, 100 | spawn_blocked, spawn_blocked |
| qwen08 | 20260925 | snake | 20, 50 | no_legal_actions, no_legal_actions |
| qwen08 | 20260926 | tetris | 0, 0 | spawn_blocked, spawn_blocked |
| qwen08 | 20260926 | snake | 70, 50 | no_legal_actions, no_legal_actions |

## 请求失败现场

- 20260925/0/jev/snake：已执行 1035 步；Bad state: API 502: {"detail":"JEV HTTP 529"}
- 20260925/1/jev/snake：已执行 275 步；ClientException: Connection closed before full header was received, uri=http://127.0.0.1:8770/v1/tool-decision
- 20260926/0/jev/snake：已执行 0 步；ClientException with SocketException: Connection refused (OS Error: Connection refused, errno = 61), address = 127.0.0.1, port = 63867, uri=http://127.0.0.1:8770/v1/tool-decision
- 20260926/0/jev/tetris：已执行 0 步；ClientException with SocketException: Connection refused (OS Error: Connection refused, errno = 61), address = 127.0.0.1, port = 63851, uri=http://127.0.0.1:8770/v1/tool-decision
- 20260926/1/jev/snake：已执行 0 步；ClientException with SocketException: Connection refused (OS Error: Connection refused, errno = 61), address = 127.0.0.1, port = 63896, uri=http://127.0.0.1:8770/v1/tool-decision
- 20260926/1/jev/tetris：已执行 0 步；ClientException with SocketException: Connection refused (OS Error: Connection refused, errno = 61), address = 127.0.0.1, port = 63886, uri=http://127.0.0.1:8770/v1/tool-decision
- 20260926/1/laya/snake：已执行 0 步；ClientException with SocketException: Connection refused (OS Error: Connection refused, errno = 61), address = 127.0.0.1, port = 63920, uri=http://127.0.0.1:8769/v1/tool-decision?native=true
- 20260926/1/laya/tetris：已执行 0 步；ClientException with SocketException: Connection refused (OS Error: Connection refused, errno = 61), address = 127.0.0.1, port = 63914, uri=http://127.0.0.1:8769/v1/tool-decision?native=true

候选顺序与编号共同置换，变化属于展示敏感性；云端非确定性也可能参与，单次重复不能将差异全归因于顺序。

## 调用与终止

| 模型 | 请求总数 | 到达动作上限 | 请求/协议/执行错误 | 实际模型 |
| --- | ---: | --- | ---: | --- |
| random | 0 | 0/12 | 0 | random-only |
| program | 0 | 12/12 | 0 | program-only |
| jev | 5391 | 2/12 | 6 | None, jev-1.13.0 |
| laya | 4730 | 0/12 | 2 | None, aac6fef/laya-multilingual-mlx |
| qwen08 | 4396 | 0/12 | 0 | mlx-community/Qwen3.5-0.8B-4bit |

三个游戏种子仅提供探索性证据，不作统计显著性判断。各策略走出不同轨迹后，模型面对的实际局面也不同；对照的是共同规则和初始条件下的整局结果。

离线核验：

```text
Verified 60 decision-v1 runs, 47221 actual actions; no strategy correction, all within recorded caps.
```

逐步证据见 runs/；配置、模型健康信息和源码哈希见 metadata.json，源码副本见 source/。未进行浏览器端到端验收。

补充核对：4728 次 Laya 响应完整保留输入且未截断；4396 次 Qwen 执行响应确认格式约束。所有轨迹无纠错，随机/程序在不同展示排列下逐帧一致。

调度记录：起初串行，按用户要求中途切换为 JEV 单独串行、其余本地模型和基线在第二队列串行，两队列并行。原始局未重跑，起始配置见 metadata.json，切换记录见 parallel-status.json。不据此比较公平延迟。
